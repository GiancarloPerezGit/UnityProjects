﻿using UnityEngine;
using System;
public class ClockScript : MonoBehaviour
{

    public Transform hoursTransform;
    public Transform minutesTransform;
    public Transform secondsTransform;
    public bool continuous;
    private void UpdateContinuous()
    {
        TimeSpan clockTime = DateTime.Now.TimeOfDay;
        hoursTransform.localRotation = Quaternion.Euler(0f, (float)clockTime.TotalHours * 30f, 0f);
        minutesTransform.localRotation = Quaternion.Euler(0f, (float)clockTime.TotalMinutes * 6f, 0f);
        secondsTransform.localRotation = Quaternion.Euler(0f, (float)clockTime.TotalSeconds * 6f, 0f);
    }
    private void UpdateDiscrete()
    {
        DateTime clockTime = DateTime.Now;
        hoursTransform.localRotation = Quaternion.Euler(0f, clockTime.Hour * 30f, 0f);
        minutesTransform.localRotation = Quaternion.Euler(0f, clockTime.Minute * 6f, 0f);
        secondsTransform.localRotation = Quaternion.Euler(0f, clockTime.Second * 6f, 0f);
    }
    private void Update()
    {
        if(continuous)
        {
            UpdateContinuous();
        }
        else
        {
            UpdateDiscrete();
        }
    }
}