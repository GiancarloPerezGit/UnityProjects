﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SquareMov2 : MonoBehaviour
{
    // Start is called before the first frame update
    float startX = 0;
    float startY = 0;
    int counter = 0;

    public SquareMov5 nextSquare;

    void Start()
    {
        //Vector3 spawn = new Vector3(Random.Range(-5, 4) + 0.5f, Random.Range(-5, 4) + 0.5f, 0);
        //gameObject.transform.position = spawn;
    }

    void Awake()
    {

    }

    public float randX()
    {
        startX = Random.Range(-5, 4) + 0.5f;
        return startX;
    }

    public float randY()
    {
        startY = Random.Range(-5, 4) + 0.5f;
        return startY;
    }

    public void spawn()
    {
        Vector3 spawn = new Vector3(startX, startY, 0);
        gameObject.transform.position = spawn;
    }



    public void counterShift(int x)
    {
        counter = x;
    }

    public void instruct()
    {
        if (counter == 0)
        {
            gameObject.transform.position += Vector3.right;
            counter = -1;
            nextSquare.counterShift(0);
            nextSquare.wat();
        }
    }

    public void wat()
    {
        Invoke("instruct", 2.0f);
    }

    // Update is called once per frame
    void Update()
    {

    }
}
