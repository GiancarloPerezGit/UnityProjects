﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    // Start is called before the first frame update
    public SquareMov firstSquare;
    public SquareMov2 secondSquare;
    public SquareMov3 thirdSquare;
    public SquareMov4 fourthSquare;
    public SquareMov5 fifthSquare;
    public SquareMov6 sixthSquare;

    public CircleMove firstCircle;
    public CircleMove2 secondCircle;
    public CircleMove3 thirdCircle;

    public TriangleMove firstTriangle;
    public TriangleMove2 secondTriangle;
    public TriangleMove3 thirdTriangle;

    bool switc = true;

    float square0X;
    float square0Y;
    float square1X;
    float square1Y;
    float square2X;
    float square2Y;
    float square3X;
    float square3Y;
    float square4X;
    float square4Y;
    float square5X;
    float square5Y;


    void Start()
    {
        square1X = firstSquare.randX();
        square1Y = firstSquare.randY();
        firstSquare.spawn();

        do
        {
            square2X = secondSquare.randX();
            square2Y = secondSquare.randY();

            if (square2X != square1X || square2Y != square1Y)
            {

                secondSquare.spawn();
                switc = false;

            }

        } while (switc);

        switc = true;

        do
        {
            square3X = thirdSquare.randX();
            square3Y = thirdSquare.randY();

            if (square3X != square1X && square3X != square2X || square3Y != square1Y && square3Y != square2Y)
            {

                thirdSquare.spawn();
                switc = false;

            }

        } while (switc);

        switc = true;

        do
        {
            square4X = fourthSquare.randX();
            square4Y = fourthSquare.randY();

            if (square4X != square1X && square4X != square2X && square4X != square3X || square4Y != square1Y && square4Y != square2Y && square4Y != square3Y)
            {

                fourthSquare.spawn();
                switc = false;

            }

        } while (switc);

        switc = true;

        do
        {
            square5X = fifthSquare.randX();
            square5Y = fifthSquare.randY();

            if (square5X != square1X && square5X != square2X && square5X != square3X && square5X != square4X || square5Y != square1Y && square5Y != square2Y && square5Y != square3Y && square5Y != square4Y)
            {   

                fifthSquare.spawn();
                switc = false;

            }

        } while (switc);

        switc = true;

        do
        {
            square0X = sixthSquare.randX();
            square0Y = sixthSquare.randY();

            if (square0X != square1X && square0X != square2X && square0X != square3X && square0X != square4X && square0X != square5X || square0Y != square1Y && square0Y != square2Y && square0Y != square3Y && square0Y != square4Y && square0Y != square5Y)
            {

                sixthSquare.spawn();
                switc = false;

            }

        } while (switc);

        firstCircle.mov();
        secondCircle.mov();
        thirdCircle.mov();
        firstTriangle.mov();
        secondTriangle.mov();
        thirdTriangle.mov();
        firstSquare.wat();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
