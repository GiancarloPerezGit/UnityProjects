﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CircleMove2 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void mov()
    {
        gameObject.transform.position = GameObject.Find("Square (1)").transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        gameObject.transform.position = GameObject.Find("Square (1)").transform.position;
    }
}
